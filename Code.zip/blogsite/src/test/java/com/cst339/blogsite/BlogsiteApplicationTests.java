package com.cst339.blogsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
