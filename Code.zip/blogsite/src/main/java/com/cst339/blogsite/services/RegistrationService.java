package com.cst339.blogsite.services;

import com.cst339.blogsite.models.User;

public interface RegistrationService {
    boolean registerUser(User user);
}
