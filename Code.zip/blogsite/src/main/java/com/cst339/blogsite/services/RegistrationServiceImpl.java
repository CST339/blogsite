package com.cst339.blogsite.services;

import com.cst339.blogsite.models.User;

public class RegistrationServiceImpl implements RegistrationService {
    @Override
    public boolean registerUser(User user) {
        // Logic to register the user, interacting with repositories or databases
        return true; // Return success/failure
    }
}
