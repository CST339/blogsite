package com.cst339.blogsite.services;

public class LoginServiceImpl implements LoginService {

    // Verifies credentials
    public boolean verifyLogin(String username, String password) {

        // Put logic here to check that the username and password match with the
        // database
        return true;
    }

}
