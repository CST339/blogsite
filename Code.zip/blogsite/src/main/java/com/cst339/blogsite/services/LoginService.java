package com.cst339.blogsite.services;

public interface LoginService {

    public boolean verifyLogin(String username, String password);

}
